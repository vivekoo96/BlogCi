<?php
function pr($str){
         echo '<pre>';
         print_r($str);
         echo '<br>';
}

function prx($str){
         echo '<pre>';
         print_r($str);
         die();
}

function make_valid_image_name($str){
	$str=str_replace("'","_",$str);
	$str=str_replace('"',"_",$str);
	$str=str_replace('(',"_",$str);
	$str=str_replace(')',"_",$str);
	$str=str_replace('!',"_",$str);
	$str=str_replace('-',"_",$str);
	$str=str_replace(' ',"_",$str);
	$num=rand(000000,999999);
	$str=$num.'_'.$str;
	return strtolower($str);
}

function getCategory($id=''){
	$CI =& get_instance();
    $query = $CI->db->query("SELECT id,category_name from category where status!='-1' order by category_name asc");
	$HTML='';	  
	if($query->num_rows() > 0)
	{
		$HTML.='<select name="cat_id" id="cat_id" class="form-control">';
			if($id==''){
				$HTML.='<option value="-1">Select Category</option>';
			}
			foreach($query->result() as $row){
				if($id==$row->id){
					$HTML.='<option value="'.$row->id.'" selected="selected">'.$row->category_name.'</option>';
				}else{
					$HTML.='<option value="'.$row->id.'">'.$row->category_name.'</option>';
				}
				
			}
		$HTML.='</select>';
	}
	echo $HTML;
}
?>