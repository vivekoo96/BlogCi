<?php
 class adminModel extends CI_Model{

    public function check_admin($username,$password){
        $this->db->select('id,status');
        $this->db->from('admin_user');
        $this->db->where('username',$username);
        $this->db->where('password',$password);
        $query = $this->db->get();
        return $query->result();
    }


    public function insert_data($table,$data){
        $this->db->insert($table,$data);
    }

    public function get_data($id){
      $this->db->select('id,category_name,added_on,status');
      $this->db->where_not_in('status','-1');
      $this->db->from('category');
      if($id!=''){
        $this->db->where('id',$id);
    }
      $query = $this->db->get();
      return $query->result();
    }
    public function get_post($id){
        $this->db->select('post.title,post.descre,post.cat_id,post.image,post.added_on,category.category_name,post.status,post.id');
        $this->db->where_not_in('post.status','-1');
        $this->db->from('post');
        $this->db->join('category','category.id = post.cat_id','left');
        if($id!=''){
          $this->db->where('post.id',$id);
      }
        $query = $this->db->get();
        return $query->result();
    }

    public function update_data($table,$data,$id){
        $this->db->where('id',$id);
        $this->db->update($table,$data);
    }
    public function delete($table,$id){
        $this->db->where('id',$id);
        $data['status'] = -1;
        $this->db->update($table,$data);


    }
 }

 


?>