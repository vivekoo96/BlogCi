<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
public function __construct()
{
	parent::__construct();
	$this->load->model('adminModel');
	$this->load->helper('url');
	$this->load->helper('comman_helper');
	session_start();
}
	public function id_session(){
		if(isset($_SESSION['islogin']) && $_SESSION['islogin'] !=''){

		}else{
			header('location:index');
			die();
		}
	}
	public function index()
	{
		if(isset($_SESSION['islogin']) && $_SESSION['islogin'] != ''){
			header('location:post');
		}
		$this->load->view('index');
	}

	public function post()
	{
		$this->id_session();
		$this->load->view('header');
		$result['data'] = $this->adminModel->get_post($id='');
		$this->load->view('post',$result);
		$this->load->view('footer');
	}
	public function check_admin(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$result = $this->adminModel->check_admin($username,$password);
		if(isset($result['0'])){
			$status = $result['0']->status;
			if($status ==1){
				$arr = array('result' => 'success');
				$_SESSION['islogin']  = 'yes';

			}else{
				$arr = array('result'=>'error','msg'=>'Your Acount Deactivate.');
			}
		}else{
			$arr = array('msg'=>'Please enter Vaild details.');
		}
		echo json_encode($arr);
	}
	public function add_post($id = "")
	{
		$this->id_session();
		$this->load->view('header');
		if($id!=""){
		        $result = $this->adminModel->get_post($id);
				$data['title'] = $result['0']->title;
				$data['cat_id'] = $result['0']->cat_id;
				$data['id'] = $result['0']->id;
				$data['category_name'] = $result['0']->category_name;
				$data['descre'] = $result['0']->descre;
				$data['image'] = $result['0']->image;
		}else{
				$data['title'] = "";
				$data['cat_id'] = "";
				$data['id'] = "";
				$data['category_name'] = "";
				$data['descre'] ="";
				$data['image'] = "";
		}
		$this->load->view('add_post',$data);
		$this->load->view('footer');
	}
	public function category()
	{
		$this->id_session();
		$result['data'] = $this->adminModel->get_data($id='');
		$this->load->view('header');
		$this->load->view('cotagrey',$result);
		$this->load->view('footer');
	}

	public function add_cotagrey($id='')
	{
		$this->id_session();
		$this->load->view('header');
		if($id!=''){
		     $result = $this->adminModel->get_data($id);
			 $data['category_name'] = $result['0']->category_name;
			$data['id'] = $id;
		}else{
			$data['category_name'] ='';
			$data['id'] = '';
		}
		$this->load->view('add_cotagrey',$data);
		$this->load->view('footer');
	}
	
	public function status($type,$table,$id){
		$this->id_session();
		$data['status'] = $type;
		$this->adminModel->update_data($table,$data,$id);
		header('location:'.SITE_PATH.'admin/'.$table);
	}
	public function insert_cotagrey(){
		$data['category_name'] = $this->input->post('cotagrey');
		$id = $this->input->post('id');
		if($id>0){
			$result = $this->adminModel->update_data('category',$data,$id);
			echo "Added On";
		}else{
		$data['status'] = 1;
		$data['added_on'] = date('Y-m-d h:i:s');
		$result = $this->adminModel->insert_data('category',$data);
		echo "Added on";
		}
	}
		public function submit_post(){
			$this->id_session();
			if(isset($_POST['submit'])){
			$id = $this->input->post('id');
			if($id>0){
				$title = $this->input->post('title');
				$cat_id = $this->input->post('cat_id');
				$image = $this->input->post('image');
				$temp_name = $_FILES['image']['tmp_name'];
				$file_name = $_FILES['image']['name'];
				$file_size = $_FILES['image']['size'];
				$file_size = $_FILES['image']['type'];
				move_uploaded_file($temp_name,'image/'.$file_name);
				$desc = $this->input->post('desc');
				$data['title'] = $title;
				$data['cat_id'] = $cat_id;
				$data['image'] = $file_name;
				$data['descre'] = $desc;
				$data['status'] = 1;
				$data['added_on'] = date('Y-m-d h:i:s');
				$this->adminModel->update_data('post',$data,$id);
			}else{
				$title = $this->input->post('title');
				$cat_id = $this->input->post('cat_id');
				$image = $this->input->post('image');
				$temp_name = $_FILES['image']['tmp_name'];
				$file_name = $_FILES['image']['name'];
				$file_size = $_FILES['image']['size'];
				$file_size = $_FILES['image']['type'];
				move_uploaded_file($temp_name,'image/'.$file_name);
				$desc = $this->input->post('desc');
				$id = $this->input->post('id');
				$data['title'] = $title;
				$data['cat_id'] = $cat_id;
				$data['image'] = $file_name;
				$data['descre'] = $desc;
				$data['status'] = 1;
				$data['added_on'] = date('Y-m-d h:i:s');
				if($data['image'] ==" "){
					$data['error'] = "Please select a Image";
				}else{
					$this->adminModel->insert_data('post',$data);
				}
				
				
			}
			
			}
			header('location:'.SITE_PATH.'admin/post');

		}
	public function logout()
	{
		unset($_SESSION['islogin']);
		header('location:index');
	}
}
