<?php

header('location:index');

?>