
    <script src="<?php echo base_url()?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/tether.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/chart.js"></script>
    <script src="<?php echo base_url()?>assets/js/tablesorter.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/toolkit.js"></script>
    <script src="<?php echo base_url()?>assets/js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){while(window.BS&&window.BS.loader&&window.BS.loader.length){(window.BS.loader.pop())()}})
    </script>
  </body>
</html>
