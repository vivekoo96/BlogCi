
<div class="table-responsive">
  <table class="table" data-sort="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Categrey</th>
        <th>Title</th>
        <th>Image</th>
        <th>Added on</th>
        <th>Edit/Deactive/Delete</th>
        
      </tr>
    </thead>
    <tbody>
      <?php 
      if(isset($data['0'])){
      $num = 1;
      foreach($data as $list)
     
      {
      ?>
      <tr>
        
        <td><?php echo $num; ?></td>
        <td><?php echo $list->category_name; ?></td>
        <td><?php echo $list->title; ?></td>
        <td><?php echo "<img src='http://127.0.0.1/ciBlog/admin/image/$list->image'";?> alt="" srcset=""style="width:80px;height:80px;"></td>
        <td><?php echo $list->added_on; ?></td>
       
        <td><a href="<?php echo base_url()?>add_post/<?php echo $list->id?>">Edit</a>
        /
        <?php
        $status = $list->status; 
        if($status == 1){
        
        ?>
        <a href="<?php echo base_url()?>/status/0/post/<?php echo $list->id;?>">Active</a>
        <?php
        }else{
        ?>
        /
        <a href="<?php echo base_url();?>/status/1/post/<?php echo $list->id;?>">Deactive</a>
        <?php
        }
        ?>
        /<a href="<?php echo base_url();?>/status/-1/post/<?php echo $list->id;?>">Delete</a></td>
      </tr>
      <?php
       $num++;
      }
     
    }
      ?>
    </tbody>
  </table>
</div>
