


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Light UI &middot; 
      
    </title>

    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic" rel="stylesheet">
    
      <link href="<?php echo base_url()?>assets/css/toolkit-light.css" rel="stylesheet">
    
    
    <link href="<?php echo base_url()?>assets/css/application.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
    </style>
  </head>


<body>
  <div class="container">
    <div class="row">
      <div class="col-md-3 sidebar">
        <nav class="sidebar-nav">
          <div class="sidebar-header">
            <button class="nav-toggler nav-toggler-md sidebar-toggler" type="button" data-toggle="collapse" data-target="#nav-toggleable-md">
              <span class="sr-only">Toggle nav</span>
            </button>
            <a class="sidebar-brand img-responsive" href="index">
              <span class="icon icon-leaf sidebar-brand-icon"></span>
            </a>
          </div>

          <div class="collapse nav-toggleable-md" id="nav-toggleable-md">
            <ul class="nav nav-pills nav-stacked flex-column">
              <li class="nav-header">Admin panel</li>
              <li class="nav-item">
                <a class="nav-link " href="<?php echo base_url()?>post">Post</a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="<?php echo base_url()?>add_post">Add Post</a>
              </li>
              <li class="nav-item">
                <a class="nav-link "href="<?php echo base_url()?>category">Cotagrey</a>
              </li>
              <li class="nav-item">
                <a class="nav-link "href="<?php echo base_url()?>add_cotagrey">Add Cotagrey</a>
              </li>
            <hr class="visible-xs mt-3">
          </div>
        </nav>
      </div>
      <div class="col-md-9 content">
        <div class="dashhead">
  <div class="dashhead-titles">
    <h6 class="dashhead-subtitle">Dashboards</h6>
    <h2 class="dashhead-title">Welcome</h2>
  </div>

  <div class="btn-toolbar dashhead-toolbar">
    <div class="btn-toolbar-item input-with-icon">
    
            <ul class="nav nav-pills nav-stacked">
              <li class="nav-item">
                    <a class="nav-link "href="logout">Logout</a>
               </li>
            </ul>
    </div>
  </div>
</div>

<hr class="mt-3">