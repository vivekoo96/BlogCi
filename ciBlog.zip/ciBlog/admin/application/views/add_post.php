
<div class="row mt-2">
  <div class="col-md-10">
<form  method="post" action="<?php echo SITE_PATH;?>admin/submit_post" id="formData" name="formData" enctype="multipart/form-data">
  <div class="form-group">
    <label for="title">Title</label>
    <input type="text" class="form-control" id="title"  name="title" placeholder="Enter Title" value = "<?php echo $title;?>">
    <span id="title_error" class="field_error"></span>
  </div>
  <div class="form-group">
    <label for="Categrey">Categrey</label>
    <?php echo getCategory($cat_id)?>
    <span id="category_error" class="field_error"></span>
  </div>
  <div class="form-group">
  <label for="image">Choose Image</label>
    <input type="file" class="form-control" id="image" name="image" placeholder="Select Image">
    <span id="image_error" class="field_error"></span>
</div>

  <div class="form-group">
    <label for="desc">Description</label>
   <textarea name="desc" id="desc" cols="10" rows="5" class="form-control"><?php echo $descre;?></textarea>
   <span id="desc_error" class="field_error"></span>
  </div>
  <input type="submit" class="btn btn-primary" name="submit" value="Submit">
  <input type="hidden" id="id" name="id" value="<?php echo $id?>">
</form>

</div>
    

  
</div>
