<div class="row mt-2">
  <div class="col-md-10">
<form>
  <div class="form-group">
    <label for="title">Add Cotgery</label>
    <input type="text" class="form-control" id="cotagrey"  placeholder="Enter Cotagrey" value="<?php echo $category_name;?>">
  </div>
  <input type="hidden" id="cat_id" value="<?php echo $id;?>">
  <button type="button" class="btn btn-primary" onclick="vaild_cotgery()">Submit</button>
 
</form>
<span id="vaild_cotgery" class="field_error m-5"></span>

</div>
    

  
</div>
<script>
   function vaild_cotgery(){
          var cotagrey = jQuery('#cotagrey').val();
          var cat_id = jQuery('#cat_id').val();
          jQuery('.feild_error').html('');
          var isError = '';
          if(cotagrey == ''){
            jQuery('#vaild_cotgery').html('Please Enter Cotgery');
            isError = 'yes';
          }
          if(isError == ''){
            jQuery.ajax({
              type:'post',
              url:'<?php echo SITE_PATH;?>admin/insert_cotagrey',
              data:'cotagrey='+cotagrey+'&id='+cat_id,
              success:function(data){
                  window.location.href = '<?php echo SITE_PATH;?>admin/category';
                }
            })
          }
          
        }

</script>

