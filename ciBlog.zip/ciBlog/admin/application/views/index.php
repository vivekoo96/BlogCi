


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Login &middot; 
      
    </title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url()?>assets/css/toolkit.css" rel="stylesheet">
    
    <link href="<?php echo base_url()?>assets/css/application-login.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
    </style>

  </head>


<body>
  



<div class="container-fluid container-fill-height">
  <div class="container-content-middle">
    <form role="form" class="mx-auto text-center app-login-form">

      <a href="index" class="app-brand mb-5">
        <img src="<?php echo base_url()?>assets/img/brand.png" alt="brand">
      </a>

      <div class="form-group">
        <input class="form-control" placeholder="Username" id="username" name="username">
        <span id="username_error" class="field_error"></span>
      </div>

      <div class="form-group mb-3">
        <input type="password" class="form-control" placeholder="Password" id="password" name="password">
        <span id="password_error" class="field_error"></span>
      </div>

      <div class="mb-5">
        <button class="btn btn-primary" type="button" onclick="valid_login()">Log In</button>
      </div>
      <span id="result" class="field_error"></span>
    </form>
  </div>
</div>


    <script src="<?php echo base_url()?>assets/js/jquery.min.js"></script>    
    <script src="<?php echo base_url()?>assets/js/tether.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/chart.js"></script>
    <script src="<?php echo base_url()?>assets/js/toolkit.js"></script>
    <script src="<?php echo base_url()?>assets/js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){
        if (window.BS&&window.BS.loader&&window.BS.loader.length) {
          while(BS.loader.length){(BS.loader.pop())()}
        }
      })

        function valid_login(){
          var username = jQuery('#username').val();
          var password = jQuery('#password').val();
          var isError = '';
          jQuery('.feild_error').html('');
          if(username == ''){
            jQuery('#username_error').html('Please Enter Username');
            isError = 'yes';
          }
          if(password == ''){
            jQuery('#password_error').html('Please Enter Password');
            isError = 'yes';
          }

          if(isError == ''){
            jQuery.ajax({
              type:'post',
              url:'check_admin',
              data:'username='+username+'&password='+password,
              success:function(data){
                var response = jQuery.parseJSON(data);
                if(response.result == 'success'){
                  window.location.href = 'post';
                }else{
                  jQuery('#result').html(response.msg);
                }
              }

            })
          }
          
        }

    </script>
  </body>
</html>

