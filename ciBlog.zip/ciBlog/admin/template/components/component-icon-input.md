## Icon input

Easily overlay an icon on an input.

{% example html %}
<div class="input-with-icon">
  <input type="text" value="Example input" class="form-control">
  <span class="icon icon-calendar"></span>
</div>
{% endexample %}
